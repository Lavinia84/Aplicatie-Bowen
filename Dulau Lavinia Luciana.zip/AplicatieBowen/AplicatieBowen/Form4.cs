﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AplicațieBowen
{
    public partial class Form4 : Form
    {
        string[] raspunsuri1 = new string[25];
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Dulau\Desktop\AplicațieBowen\AplicațieBowen\BazadedateBowen.mdf;Integrated Security=True");
        public Form4(string[] raspunsuri)
        {
            InitializeComponent();
            raspunsuri1 = raspunsuri;
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            
        }
        //Legatura cu fereastra 3
        private void Inapoi_Click(object sender, EventArgs e)
        {
            this.Close();
            Form3 frm = new Form3();
            frm.Show();
        }
       
        private void Inainte_Click(object sender, EventArgs e)
        {
            raspunsuri1[13] = textBox1.Text;
            raspunsuri1[14] = textBox2.Text;
            raspunsuri1[15] = textBox3.Text;
            raspunsuri1[16] = textBox4.Text;
            raspunsuri1[17] = textBox5.Text;
            raspunsuri1[18] = textBox6.Text;
            raspunsuri1[19] = textBox7.Text;
            raspunsuri1[20] = textBox8.Text;
            raspunsuri1[21] = textBox9.Text;
            raspunsuri1[22] = textBox10.Text;
            raspunsuri1[23] = textBox11.Text;
            raspunsuri1[24] = textBox12.Text;
            this.Close();
            Form5 frm = new Form5(raspunsuri1);
            frm.Show();
        }
    }
}