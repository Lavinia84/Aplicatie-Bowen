﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AplicațieBowen
{
    public partial class Form5 : Form
    {
        string[] raspunsuri2 = new string[25];
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Dulau\Desktop\AplicațieBowen\AplicațieBowen\BazadedateBowen.mdf;Integrated Security=True");
        public Form5(string[] raspunsuri1)
        {
            InitializeComponent();
            raspunsuri2 = raspunsuri1;
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            inserare_raspunsuri();
            stergere_raspunsuri();
            actualizare_raspunsuri();
        }
        //Legatura cu fereastra 4
        private void Inapoi_Click(object sender, EventArgs e)
        {
            this.Close();
            Form4 frm = new Form4(raspunsuri2);
            frm.Show();
        }
        //Adaugare raspunsuri
        private void Adaugare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Intrebari values('" + raspunsuri2[0] + "','" + raspunsuri2[1] + "','" + raspunsuri2[2] + "','" + raspunsuri2[3] + "','" + raspunsuri2[4] + "','" + raspunsuri2[5] + "','" + raspunsuri2[6] + "','" + raspunsuri2[7] + "','" + raspunsuri2[8] + "','" + raspunsuri2[9] + "','" + raspunsuri2[10] + "','" + raspunsuri2[11] + "','" + raspunsuri2[12] + "','" + raspunsuri2[13] + "','" + raspunsuri2[14] + "','" + raspunsuri2[15] + "','" + raspunsuri2[16] + "','" + raspunsuri2[17] + "','" + raspunsuri2[18] + "','" + raspunsuri2[19] + "','" + raspunsuri2[20] + "','" + raspunsuri2[21] + "','" + raspunsuri2[22] + "','" + raspunsuri2[23] + "','" + raspunsuri2[24] + "','" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + textBox8.Text + "','" + textBox9.Text + "','" + textBox10.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
            inserare_raspunsuri();
            MessageBox.Show("Inregistrare facuta cu succes!");
        }
        //Adaugare 
        public void inserare_raspunsuri()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Intrebari";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Stergere raspunsuri
        private void Stergere_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from Intrebari where Id_pacient='" + raspunsuri2[0] + "'";
            cmd.ExecuteNonQuery();
            con.Close();
            stergere_raspunsuri();
            MessageBox.Show("Stergere facuta cu succes!");
        }
        //Stergere
        public void stergere_raspunsuri()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Intrebari";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Actualizare raspunsuri
        private void Actualizare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update Intrebari set Pb_acute_cronice_pe_care_doriti_sa_le_rezolvati_prin_Terapia_Bowen='" + raspunsuri2[1] + "',Alte_pb_acute_cronice_pe_care_le_aveti='" + raspunsuri2[2] + "',Ce_tratamente_ati_facut_pt_pb_dvs='" + raspunsuri2[3] + "',Daca_ati_avut_accidente_fizice='" + raspunsuri2[4] + "',Cazaturi_pe_coccis='" + raspunsuri2[5] + "',Operatii='" + raspunsuri2[6] + "',Socuri_emotionale='" + raspunsuri2[7] + "',Dureri_in_zona_cervical_toracica_lombara='" + raspunsuri2[8] + "',Dureri_la_incheieturi_articulatiile_mainilor_picioarelor='" + raspunsuri2[9] + "',Aveti_pb_de_celulita='" + raspunsuri2[10] + "',Dureri_de_cap_ameteli='" + raspunsuri2[11] + "',Somn_calitate_insomnie='" + raspunsuri2[12] + "',Oboseala_nervozitate_diurna='" + raspunsuri2[13] + "',Alergii='" + raspunsuri2[14] + "',Tiroida='" + raspunsuri2[15] + "',Hepatita='" + raspunsuri2[16] + "',Diabet='" + raspunsuri2[17] + "',Colesterol='" + raspunsuri2[18] + "',Tensiune_arteriala='" + raspunsuri2[19] + "',Pb_de_circulatie_sangvina='" + raspunsuri2[20] + "',Pb_digestive='" + raspunsuri2[21] + "',Pb_renale='" + raspunsuri2[22] + "',Pb_sani_PMS='" + raspunsuri2[23] + "',Sarcina='" + raspunsuri2[24] + "',Pb_genito_urinare='" + textBox1.Text + "',Pb_dentare_TMJ_extractii_operatii_proteze='" + textBox2.Text + "',Pb_ORL_sinuzite='" + textBox3.Text + "',Lichide='" + textBox4.Text + "',Fumati_ati_fumat_de_cand_ati_renuntat='" + textBox5.Text + "',Hobiuri_exercitii_fizice='" + textBox6.Text + "',Conditie_fizica_luati_medicamente='" + textBox7.Text + "',Gradul_de_toxicitate='" + textBox8.Text + "',Sanatate_psihologica_si_emotionala='" + textBox9.Text + "',Resurse_spirituale='" + textBox10.Text + "' where Id_pacient='" + raspunsuri2[0] + "'";
            cmd.ExecuteNonQuery();
            con.Close();
            actualizare_raspunsuri();
            MessageBox.Show("Actualizare facuta cu succes!");
        }
        //Actualizare
        public void actualizare_raspunsuri()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Intrebari";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Cautare raspunsuri
        private void Cautare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Intrebari where Id_pacient='" + raspunsuri2[0] + "' or Pb_acute_cronice_pe_care_doriti_sa_le_rezolvati_prin_Terapia_Bowen ='" + raspunsuri2[1] + "' or Alte_pb_acute_cronice_pe_care_le_aveti='" + raspunsuri2[2] + "' or Ce_tratamente_ati_facut_pt_pb_dvs='" + raspunsuri2[3] + "' or Daca_ati_avut_accidente_fizice='" + raspunsuri2[4] + "' or Cazaturi_pe_coccis='" + raspunsuri2[5] + "' or Operatii='" + raspunsuri2[6] + "' or Socuri_emotionale='" + raspunsuri2[7] + "' or Dureri_in_zona_cervical_toracica_lombara='" + raspunsuri2[8] + "' or Dureri_la_incheieturi_articulatiile_mainilor_picioarelor='" + raspunsuri2[9] + "' or Aveti_pb_de_celulita='" + raspunsuri2[10] + "' or Dureri_de_cap_ameteli='" + raspunsuri2[11] + "' or Somn_calitate_insomnie='" + raspunsuri2[12] + "' or Oboseala_nervozitate_diurna='" + raspunsuri2[13] + "' or Alergii='" + raspunsuri2[14] + "' or Tiroida='" + raspunsuri2[15] + "' or Hepatita='" + raspunsuri2[16] + "' or Diabet='" + raspunsuri2[17] + "' or Colesterol='" + raspunsuri2[18] + "' or Tensiune_arteriala='" + raspunsuri2[19] + "' or Pb_de_circulatie_sangvina='" + raspunsuri2[20] + "' or Pb_digestive='" + raspunsuri2[21] + "' or Pb_renale='" + raspunsuri2[22] + "' or Pb_sani_PMS='" + raspunsuri2[23] + "' or Sarcina='" + raspunsuri2[24] + "' or Pb_genito_urinare='" + textBox1.Text + "' or Pb_dentare_TMJ_extractii_operatii_proteze='" + textBox2.Text + "' or Pb_ORL_sinuzite='" + textBox3.Text + "' or Lichide='" + textBox4.Text + "' or Fumati_ati_fumat_de_cand_ati_renuntat='" + textBox5.Text + "' or Hobiuri_exercitii_fizice='" + textBox6.Text + "' or Conditie_fizica_luati_medicamente='" + textBox7.Text + "' or Gradul_de_toxicitate='" + textBox8.Text + "' or Sanatate_psihologica_si_emotionala='" + textBox9.Text + "' or Resurse_spirituale='" + textBox10.Text + "'";

            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
            MessageBox.Show("Cautare facuta cu succes!");
        }
        //Inapoi la meniu
        private void Meniu_Click(object sender, EventArgs e)
        {
            this.Close();
            Logare frm = new Logare();
            frm.Show();
        }
    }
}
