﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AplicațieBowen
{
    public partial class Form6 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Dulau\Desktop\AplicațieBowen\AplicațieBowen\BazadedateBowen.mdf;Integrated Security=True");
        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            inserare_proceduri();
            stergere_proceduri();
            actualizare_proceduri();
        }
        //Legatura cu ferestra 7
        private void Intalnire_Click(object sender, EventArgs e)
        {
            this.Close();
            Form7 frm = new Form7();
            frm.Show();
        }
        //Adaugare proceduri
        private void Adaugare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Indicatii_de_utilizare values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + textBox8.Text + "','" + textBox9.Text + "','" + textBox10.Text + "','" + textBox11.Text + "','" + textBox12.Text + "','" + textBox13.Text + "','" + textBox14.Text + "','" + textBox15.Text + "','" + textBox16.Text + "','" + textBox17.Text + "','" + textBox18.Text + "','" + textBox19.Text + "','" + textBox20.Text + "','" + textBox21.Text + "','" + textBox22.Text + "','" + textBox23.Text + "','" + textBox24.Text + "','" + textBox25.Text + "','" + textBox26.Text + "','" + textBox27.Text + "','" + textBox28.Text + "','" + textBox29.Text + "','" + textBox30.Text + "','" + textBox31.Text + "','" + textBox32.Text + "','" + textBox33.Text + "','" + textBox34.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
            inserare_proceduri();
            MessageBox.Show("Inregistrare facuta cu succes!");
        }
        //Adaugare 
        public void inserare_proceduri()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Indicatii_de_utilizare";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Stergere proceduri
        private void Stergere_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from Indicatii_de_utilizare where Nume='" + textBox1.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();
            stergere_proceduri();
            MessageBox.Show("Stergere facuta cu succes!");
        }
        //Stergere
        public void stergere_proceduri()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Indicatii_de_utilizare";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Actualizare proceduri
        private void Actualizare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update Indicatii_de_utilizare set Pb_1='" + textBox2.Text + "',Pb_2='" + textBox3.Text + "',Pb_3='" + textBox4.Text + "',Pb_4='" + textBox5.Text + "',Pb_5='" + textBox6.Text + "',Pb_6='" + textBox7.Text + "',Pb_7='" + textBox8.Text + "',Pb_8='" + textBox9.Text + "',Pb_9='" + textBox10.Text + "',Pb_10='" + textBox11.Text + "',Pb_11='" + textBox12.Text + "',Pb_12='" + textBox13.Text + "',Pb_13='" + textBox14.Text + "',Pb_14='" + textBox15.Text + "',Pb_15='" + textBox16.Text + "',Pb_16='" + textBox17.Text + "',Pb_17='" + textBox18.Text + "',Pb_18='" + textBox19.Text + "',Pb_19='" + textBox20.Text + "',Pb_20='" + textBox21.Text + "',Pb_21='" + textBox22.Text + "',Pb_22='" + textBox23.Text + "',Pb_23='" + textBox24.Text + "',Pb_24='" + textBox25.Text + "',Pb_25='" + textBox26.Text + "',Pb_26='" + textBox27.Text + "',Pb_27='" + textBox28.Text + "',Pb_28='" + textBox29.Text + "',Pb_29='" + textBox30.Text + "',Pb_30='" + textBox31.Text + "',Pb_31='" + textBox32.Text + "',Pb_32='" + textBox33.Text + "',Pb_33='" + textBox34.Text + "' where Nume='" + textBox1.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();
            actualizare_proceduri();
            MessageBox.Show("Actualizare facuta cu succes!");
        }
        //Actualizare
        public void actualizare_proceduri()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Indicatii_de_utilizare";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Cautare proceduri
        private void Cautare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Indicatii_de_utilizare where Nume='" + textBox1.Text + "' or Pb_1='" + textBox2.Text + "' or Pb_2='" + textBox3.Text + "' or Pb_3='" + textBox4.Text + "' or Pb_4='" + textBox5.Text + "' or Pb_5='" + textBox6.Text + "' or Pb_6='" + textBox7.Text + "' or Pb_7='" + textBox8.Text + "' or Pb_8='" + textBox9.Text + "' or Pb_9='" + textBox10.Text + "' or Pb_10='" + textBox11.Text + "' or Pb_11='" + textBox12.Text + "' or Pb_12='" + textBox13.Text + "' or Pb_13='" + textBox14.Text + "' or Pb_14='" + textBox15.Text + "' or Pb_15='" + textBox16.Text + "' or Pb_16='" + textBox17.Text + "' or Pb_17='" + textBox18.Text + "' or Pb_18='" + textBox19.Text + "' or Pb_19='" + textBox20.Text + "' or Pb_20='" + textBox21.Text + "' or Pb_21='" + textBox22.Text + "' or Pb_22='" + textBox23.Text + "' or Pb_23='" + textBox24.Text + "' or Pb_24='" + textBox25.Text + "' or Pb_25='" + textBox26.Text + "' or Pb_26='" + textBox27.Text + "' or Pb_27='" + textBox28.Text + "' or Pb_28='" + textBox29.Text + "' or Pb_29='" + textBox30.Text + "' or Pb_30='" + textBox31.Text + "' or Pb_31='" + textBox32.Text + "' or Pb_32='" + textBox33.Text + "' or Pb_33='" + textBox34.Text + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
            MessageBox.Show("Cautare facuta cu succes!");
        }
        //Inapoi la meniu
        private void Meniu_Click(object sender, EventArgs e)
        {
            this.Close();
            Logare frm = new Logare();
            frm.Show();
        }
    }
}