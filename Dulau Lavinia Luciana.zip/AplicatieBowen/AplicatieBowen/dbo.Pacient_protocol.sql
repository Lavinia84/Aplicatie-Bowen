﻿CREATE TABLE [dbo].[Pacient_protocol]
(
	[Id_pacient_protocol] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Id_pacient] INT NOT NULL, 
    [Id_protocol] INT NOT NULL, 
    CONSTRAINT [FK_Pacient_protocol_Date_generale_despre_pacient] FOREIGN KEY ([Id_pacient]) REFERENCES [Date_generale_despre_pacient]([Id_pacient]), 
    CONSTRAINT [FK_Pacient_protocol_Protocoale] FOREIGN KEY ([Id_protocol]) REFERENCES [Protocoale]([Id_protocol])
)
