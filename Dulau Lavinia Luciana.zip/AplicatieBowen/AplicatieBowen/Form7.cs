﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AplicațieBowen
{
    public partial class Form7 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Dulau\Desktop\AplicațieBowen\AplicațieBowen\BazadedateBowen.mdf;Integrated Security=True");
        public Form7()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            inserare_intalniri();
            stergere_intalniri();
            actualizare_intalnire();
        }
        //Legatura cu procedurile
        private void Inapoi_Click(object sender, EventArgs e)
        {
            this.Close();
            Form6 frm = new Form6();
            frm.Show();
        }
        //Adaugare intalniri
        private void Adaugare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Intalniri values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
            inserare_intalniri();
            MessageBox.Show("Inregistrare facuta cu succes!");
        }
        //Adaugare 
        public void inserare_intalniri()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Intalniri";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Stergere intalniri
        private void Stergere_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from Intalniri where Id_pacient='" + textBox1.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();
            stergere_intalniri();
            MessageBox.Show("Stergere facuta cu succes!");
        }
        //Stergere
        public void stergere_intalniri()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Intalniri";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Actualizare intalniri
        private void Actualizare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update Intalniri set Data='" + textBox2.Text + "',Nume_procedura='" + textBox3.Text + "' where Id_pacient='" + textBox1.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();
            actualizare_intalnire();
            MessageBox.Show("Actualizare facuta cu succes!");
        }
        //Actualizare
        public void actualizare_intalnire()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Intalniri";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Cautare intalniri
        private void Cautare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Intalniri where Id_pacient like '" + textBox1.Text + "' or Data like '" + textBox2.Text + "' or Nume_procedura like '" + textBox3.Text + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
            MessageBox.Show("Cautare facuta cu succes!");
        }
        //Inapoi la meniu
        private void Meniu_Click(object sender, EventArgs e)
        {
            this.Close();
            Logare frm = new Logare();
            frm.Show();
        }
    }
}
