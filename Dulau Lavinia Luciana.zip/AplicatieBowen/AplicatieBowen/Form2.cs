﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AplicațieBowen
{
    public partial class Form2 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Dulau\Desktop\AplicațieBowen\AplicațieBowen\BazadedateBowen.mdf;Integrated Security=True");
        public Form2()
        {
            InitializeComponent();
        }
        //Adaugare date
        private void Adaugare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Date_generale_despre_pacient values('" + textBox1.Text + "','" + textBox2.Text + "','" + dateTimePicker1.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + textBox8.Text + "','" + textBox9.Text + "','" + textBox10.Text + "','" + textBox11.Text + "','" + textBox12.Text + "','" + textBox13.Text + "','" + textBox14.Text + "','" + textBox15.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
            inserare_date();
            MessageBox.Show("Inregistrare facuta cu succes!");
        }
        //Alegerea datei si afisarea varstei
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime from = dateTimePicker1.Value;
            DateTime to = DateTime.Now;
            TimeSpan TSpan = to - from;
            double days = TSpan.TotalDays;
            textBox6.Text = (days / 365).ToString("0");
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            

        }
        //Adaugare 
        public void inserare_date()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Date_generale_despre_pacient";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            inserare_date();
            stergere_date();
            actualizare_date();

        }
        //Stergere
        public void stergere_date()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Date_generale_despre_pacient";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Stergere date
        private void Stergere_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from Date_generale_despre_pacient where Nume='" + textBox1.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();
            stergere_date();
            MessageBox.Show("Stergere facuta cu succes!");
        }
        //Actualizare date
        private void Actualizare_Click(object sender, EventArgs e)
        {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update Date_generale_despre_pacient set Greutatea='" + Convert.ToDecimal(textBox8.Text) + "',Inaltimea='" + Convert.ToDecimal(textBox9.Text) + "',Telefon='" + textBox10.Text + "',Email='" + textBox11.Text + "',Adresa='" + textBox12.Text + "',Ocupatia='" + textBox13.Text + "' where Nume='" + textBox1.Text + "'";
                cmd.ExecuteNonQuery();
                con.Close();
                actualizare_date();
                MessageBox.Show("Actualizare facuta cu succes!");
        }
        //Actualizare
        public void actualizare_date()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Date_generale_despre_pacient";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Cautare date
        private void Cautare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Date_generale_despre_pacient where Nume like '" + textBox1.Text + "' or Prenume like '" + textBox2.Text + "' or Data_nasterii like '" + dateTimePicker1.Text + "' or Nr_A like '" + textBox4.Text + "' or Nr_B like '" + textBox5.Text + "' or Varsta like'" + textBox6.Text + "' or Sex='" + textBox7.Text + "' or Greutatea like '" + textBox8.Text + "' or Inaltimea like '" + textBox9.Text + "' or Telefon like '" + textBox10.Text + "' or Email like '" + textBox11.Text + "' or Adresa like '" + textBox12.Text + "' or Ocupatia like '" + textBox13.Text + "' or Medicul_care_se_ocupa_de_pb_dvs_de_sanatate like '" + textBox14.Text + "' or De_unde_aveti_ref_despre_Terapia_Bowen like '" + textBox15.Text + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
            MessageBox.Show("Cautare facuta cu succes!");
        }
        //Inapoi la meniu
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Logare frm = new Logare();
            frm.Show();
        }
    }

}
