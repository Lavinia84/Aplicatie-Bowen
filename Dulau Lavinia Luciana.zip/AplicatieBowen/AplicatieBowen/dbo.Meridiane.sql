﻿CREATE TABLE [dbo].[Meridiane]
(
	[Id_meridian] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Id_pacient] INT NOT NULL, 
    [Id_procedura] INT NOT NULL, 
    [Nume] NVARCHAR(50) NOT NULL, 
    [Pb_1] NVARCHAR(MAX) NOT NULL, 
    [Pb_2] NVARCHAR(MAX) NOT NULL, 
    [Pb_3] NVARCHAR(MAX) NOT NULL, 
    [Pb_4] NVARCHAR(MAX) NOT NULL, 
    [Pb_5] NVARCHAR(MAX) NOT NULL, 
    [Pb_6] NVARCHAR(MAX) NOT NULL, 
    [Pb_7] NVARCHAR(MAX) NOT NULL, 
    [Pb_8] NVARCHAR(MAX) NOT NULL, 
    [Pb_9] NVARCHAR(MAX) NOT NULL, 
    [Pb_10] NVARCHAR(MAX) NOT NULL, 
    [Proc_1] NVARCHAR(50) NOT NULL, 
    [Proc_2] NVARCHAR(50) NOT NULL, 
    [Proc_3] NVARCHAR(50) NOT NULL, 
    [Proc_4] NVARCHAR(50) NOT NULL, 
    [Proc_5] NVARCHAR(50) NOT NULL, 
    [Proc_6] NVARCHAR(50) NOT NULL
)
