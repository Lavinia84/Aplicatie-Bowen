﻿namespace AplicațieBowen
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.Nume = new System.Windows.Forms.Label();
            this.Prenume = new System.Windows.Forms.Label();
            this.Datanasteri = new System.Windows.Forms.Label();
            this.NrA = new System.Windows.Forms.Label();
            this.NrB = new System.Windows.Forms.Label();
            this.Varsta = new System.Windows.Forms.Label();
            this.Sex = new System.Windows.Forms.Label();
            this.Greutate = new System.Windows.Forms.Label();
            this.Inaltime = new System.Windows.Forms.Label();
            this.Telefon = new System.Windows.Forms.Label();
            this.Email = new System.Windows.Forms.Label();
            this.Adresa = new System.Windows.Forms.Label();
            this.Ocupatia = new System.Windows.Forms.Label();
            this.Medicpbsanatate = new System.Windows.Forms.Label();
            this.RefBowen = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Adaugare = new System.Windows.Forms.Button();
            this.Stergere = new System.Windows.Forms.Button();
            this.Actualizare = new System.Windows.Forms.Button();
            this.Cautare = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(135, 12);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(275, 29);
            this.textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(135, 47);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(275, 29);
            this.textBox2.TabIndex = 1;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(135, 115);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(275, 29);
            this.textBox4.TabIndex = 3;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(135, 150);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(275, 29);
            this.textBox5.TabIndex = 4;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(135, 187);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(275, 29);
            this.textBox6.TabIndex = 5;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(135, 222);
            this.textBox7.Multiline = true;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(275, 29);
            this.textBox7.TabIndex = 6;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(135, 257);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(275, 29);
            this.textBox8.TabIndex = 7;
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(135, 292);
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(275, 29);
            this.textBox9.TabIndex = 8;
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(135, 327);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(275, 29);
            this.textBox10.TabIndex = 9;
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox11.Location = new System.Drawing.Point(135, 362);
            this.textBox11.Multiline = true;
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(275, 29);
            this.textBox11.TabIndex = 10;
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox12.Location = new System.Drawing.Point(135, 397);
            this.textBox12.Multiline = true;
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(275, 29);
            this.textBox12.TabIndex = 11;
            // 
            // textBox13
            // 
            this.textBox13.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox13.Location = new System.Drawing.Point(135, 432);
            this.textBox13.Multiline = true;
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(275, 29);
            this.textBox13.TabIndex = 12;
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox14.Location = new System.Drawing.Point(457, 467);
            this.textBox14.Multiline = true;
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(249, 29);
            this.textBox14.TabIndex = 13;
            // 
            // textBox15
            // 
            this.textBox15.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox15.Location = new System.Drawing.Point(457, 502);
            this.textBox15.Multiline = true;
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(249, 29);
            this.textBox15.TabIndex = 14;
            // 
            // Nume
            // 
            this.Nume.AutoSize = true;
            this.Nume.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Nume.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nume.Location = new System.Drawing.Point(65, 12);
            this.Nume.MaximumSize = new System.Drawing.Size(500, 500);
            this.Nume.Name = "Nume";
            this.Nume.Size = new System.Drawing.Size(64, 22);
            this.Nume.TabIndex = 15;
            this.Nume.Text = "Nume:";
            this.Nume.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Prenume
            // 
            this.Prenume.AutoSize = true;
            this.Prenume.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Prenume.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Prenume.Location = new System.Drawing.Point(42, 47);
            this.Prenume.MaximumSize = new System.Drawing.Size(500, 500);
            this.Prenume.Name = "Prenume";
            this.Prenume.Size = new System.Drawing.Size(89, 22);
            this.Prenume.TabIndex = 16;
            this.Prenume.Text = "Prenume:";
            // 
            // Datanasteri
            // 
            this.Datanasteri.AutoSize = true;
            this.Datanasteri.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Datanasteri.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Datanasteri.Location = new System.Drawing.Point(12, 82);
            this.Datanasteri.MaximumSize = new System.Drawing.Size(500, 500);
            this.Datanasteri.Name = "Datanasteri";
            this.Datanasteri.Size = new System.Drawing.Size(119, 22);
            this.Datanasteri.TabIndex = 17;
            this.Datanasteri.Text = "Data nașterii:";
            // 
            // NrA
            // 
            this.NrA.AutoSize = true;
            this.NrA.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.NrA.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NrA.Location = new System.Drawing.Point(63, 119);
            this.NrA.MaximumSize = new System.Drawing.Size(500, 500);
            this.NrA.Name = "NrA";
            this.NrA.Size = new System.Drawing.Size(57, 22);
            this.NrA.TabIndex = 18;
            this.NrA.Text = "Nr. A:";
            // 
            // NrB
            // 
            this.NrB.AutoSize = true;
            this.NrB.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.NrB.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NrB.Location = new System.Drawing.Point(63, 152);
            this.NrB.MaximumSize = new System.Drawing.Size(500, 500);
            this.NrB.Name = "NrB";
            this.NrB.Size = new System.Drawing.Size(58, 22);
            this.NrB.TabIndex = 19;
            this.NrB.Text = "Nr. B:";
            // 
            // Varsta
            // 
            this.Varsta.AutoSize = true;
            this.Varsta.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Varsta.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Varsta.Location = new System.Drawing.Point(51, 187);
            this.Varsta.MaximumSize = new System.Drawing.Size(500, 500);
            this.Varsta.Name = "Varsta";
            this.Varsta.Size = new System.Drawing.Size(68, 22);
            this.Varsta.TabIndex = 20;
            this.Varsta.Text = "Vârsta:";
            // 
            // Sex
            // 
            this.Sex.AutoSize = true;
            this.Sex.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Sex.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sex.Location = new System.Drawing.Point(76, 222);
            this.Sex.MaximumSize = new System.Drawing.Size(500, 500);
            this.Sex.Name = "Sex";
            this.Sex.Size = new System.Drawing.Size(45, 22);
            this.Sex.TabIndex = 21;
            this.Sex.Text = "Sex:";
            // 
            // Greutate
            // 
            this.Greutate.AutoSize = true;
            this.Greutate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Greutate.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Greutate.Location = new System.Drawing.Point(34, 257);
            this.Greutate.MaximumSize = new System.Drawing.Size(500, 500);
            this.Greutate.Name = "Greutate";
            this.Greutate.Size = new System.Drawing.Size(94, 22);
            this.Greutate.TabIndex = 22;
            this.Greutate.Text = "Greutatea:";
            // 
            // Inaltime
            // 
            this.Inaltime.AutoSize = true;
            this.Inaltime.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Inaltime.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Inaltime.Location = new System.Drawing.Point(34, 292);
            this.Inaltime.MaximumSize = new System.Drawing.Size(500, 500);
            this.Inaltime.Name = "Inaltime";
            this.Inaltime.Size = new System.Drawing.Size(95, 22);
            this.Inaltime.TabIndex = 23;
            this.Inaltime.Text = "Înălțimea:";
            // 
            // Telefon
            // 
            this.Telefon.AutoSize = true;
            this.Telefon.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Telefon.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Telefon.Location = new System.Drawing.Point(48, 327);
            this.Telefon.MaximumSize = new System.Drawing.Size(500, 500);
            this.Telefon.Name = "Telefon";
            this.Telefon.Size = new System.Drawing.Size(74, 22);
            this.Telefon.TabIndex = 24;
            this.Telefon.Text = "Telefon:";
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Email.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Email.Location = new System.Drawing.Point(57, 362);
            this.Email.MaximumSize = new System.Drawing.Size(500, 500);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(67, 22);
            this.Email.TabIndex = 25;
            this.Email.Text = "Email:";
            // 
            // Adresa
            // 
            this.Adresa.AutoSize = true;
            this.Adresa.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Adresa.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Adresa.Location = new System.Drawing.Point(51, 398);
            this.Adresa.MaximumSize = new System.Drawing.Size(500, 500);
            this.Adresa.Name = "Adresa";
            this.Adresa.Size = new System.Drawing.Size(71, 22);
            this.Adresa.TabIndex = 26;
            this.Adresa.Text = "Adresa:";
            // 
            // Ocupatia
            // 
            this.Ocupatia.AutoSize = true;
            this.Ocupatia.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ocupatia.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ocupatia.Location = new System.Drawing.Point(35, 432);
            this.Ocupatia.MaximumSize = new System.Drawing.Size(500, 500);
            this.Ocupatia.Name = "Ocupatia";
            this.Ocupatia.Size = new System.Drawing.Size(90, 22);
            this.Ocupatia.TabIndex = 27;
            this.Ocupatia.Text = "Ocupația:";
            // 
            // Medicpbsanatate
            // 
            this.Medicpbsanatate.AutoSize = true;
            this.Medicpbsanatate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Medicpbsanatate.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Medicpbsanatate.Location = new System.Drawing.Point(12, 467);
            this.Medicpbsanatate.MaximumSize = new System.Drawing.Size(500, 500);
            this.Medicpbsanatate.Name = "Medicpbsanatate";
            this.Medicpbsanatate.Size = new System.Drawing.Size(439, 22);
            this.Medicpbsanatate.TabIndex = 28;
            this.Medicpbsanatate.Text = "Medicul care se ocupă de problemele dvs. de sănătate:";
            // 
            // RefBowen
            // 
            this.RefBowen.AutoSize = true;
            this.RefBowen.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RefBowen.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RefBowen.Location = new System.Drawing.Point(63, 502);
            this.RefBowen.MaximumSize = new System.Drawing.Size(500, 500);
            this.RefBowen.Name = "RefBowen";
            this.RefBowen.Size = new System.Drawing.Size(377, 22);
            this.RefBowen.TabIndex = 29;
            this.RefBowen.Text = "De unde aveți referințe despre Terapia Bowen:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(478, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(548, 360);
            this.dataGridView1.TabIndex = 30;
            // 
            // Adaugare
            // 
            this.Adaugare.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.Adaugare.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Adaugare.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Adaugare.Location = new System.Drawing.Point(498, 398);
            this.Adaugare.Name = "Adaugare";
            this.Adaugare.Size = new System.Drawing.Size(95, 32);
            this.Adaugare.TabIndex = 31;
            this.Adaugare.Text = "Adaugă";
            this.Adaugare.UseVisualStyleBackColor = false;
            this.Adaugare.Click += new System.EventHandler(this.Adaugare_Click);
            // 
            // Stergere
            // 
            this.Stergere.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.Stergere.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Stergere.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Stergere.Location = new System.Drawing.Point(625, 398);
            this.Stergere.Name = "Stergere";
            this.Stergere.Size = new System.Drawing.Size(100, 32);
            this.Stergere.TabIndex = 32;
            this.Stergere.Text = "Șterge";
            this.Stergere.UseVisualStyleBackColor = false;
            this.Stergere.Click += new System.EventHandler(this.Stergere_Click);
            // 
            // Actualizare
            // 
            this.Actualizare.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.Actualizare.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Actualizare.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Actualizare.Location = new System.Drawing.Point(757, 398);
            this.Actualizare.Name = "Actualizare";
            this.Actualizare.Size = new System.Drawing.Size(128, 32);
            this.Actualizare.TabIndex = 33;
            this.Actualizare.Text = "Actualizează";
            this.Actualizare.UseVisualStyleBackColor = false;
            this.Actualizare.Click += new System.EventHandler(this.Actualizare_Click);
            // 
            // Cautare
            // 
            this.Cautare.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.Cautare.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Cautare.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cautare.Location = new System.Drawing.Point(912, 397);
            this.Cautare.Name = "Cautare";
            this.Cautare.Size = new System.Drawing.Size(100, 33);
            this.Cautare.TabIndex = 34;
            this.Cautare.Text = "Caută";
            this.Cautare.UseVisualStyleBackColor = false;
            this.Cautare.Click += new System.EventHandler(this.Cautare_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dateTimePicker1.CalendarTitleBackColor = System.Drawing.Color.Green;
            this.dateTimePicker1.CalendarTitleForeColor = System.Drawing.Color.Lime;
            this.dateTimePicker1.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.dateTimePicker1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(135, 83);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(275, 29);
            this.dateTimePicker1.TabIndex = 35;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(953, 499);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 33);
            this.button1.TabIndex = 36;
            this.button1.Text = "Meniu";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(1065, 544);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.Cautare);
            this.Controls.Add(this.Actualizare);
            this.Controls.Add(this.Stergere);
            this.Controls.Add(this.Adaugare);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.RefBowen);
            this.Controls.Add(this.Medicpbsanatate);
            this.Controls.Add(this.Ocupatia);
            this.Controls.Add(this.Adresa);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.Telefon);
            this.Controls.Add(this.Inaltime);
            this.Controls.Add(this.Greutate);
            this.Controls.Add(this.Sex);
            this.Controls.Add(this.Varsta);
            this.Controls.Add(this.NrB);
            this.Controls.Add(this.NrA);
            this.Controls.Add(this.Datanasteri);
            this.Controls.Add(this.Prenume);
            this.Controls.Add(this.Nume);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Name = "Form2";
            this.Text = "Date tehnice pacient";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label Nume;
        private System.Windows.Forms.Label Prenume;
        private System.Windows.Forms.Label Datanasteri;
        private System.Windows.Forms.Label NrA;
        private System.Windows.Forms.Label NrB;
        private System.Windows.Forms.Label Varsta;
        private System.Windows.Forms.Label Sex;
        private System.Windows.Forms.Label Greutate;
        private System.Windows.Forms.Label Inaltime;
        private System.Windows.Forms.Label Telefon;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.Label Adresa;
        private System.Windows.Forms.Label Ocupatia;
        private System.Windows.Forms.Label Medicpbsanatate;
        private System.Windows.Forms.Label RefBowen;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button Adaugare;
        private System.Windows.Forms.Button Stergere;
        private System.Windows.Forms.Button Actualizare;
        private System.Windows.Forms.Button Cautare;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button1;
    }
}