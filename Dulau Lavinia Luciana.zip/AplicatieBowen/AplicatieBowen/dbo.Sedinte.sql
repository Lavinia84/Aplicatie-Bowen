﻿CREATE TABLE [dbo].[Sedinte]
(
	[Id_sedinta] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Id_protocol] INT NOT NULL, 
    [Id_pacient] INT NOT NULL, 
    [Nume_protocol] NVARCHAR(50) NOT NULL, 
    CONSTRAINT [FK_Sedinte_Protocoale] FOREIGN KEY ([Id_protocol]) REFERENCES [Protocoale]([Id_protocol])
)
