﻿CREATE TABLE [dbo].[Proceduri] (
    [Id_procedura]           INT           NOT NULL IDENTITY,
    [Id_indicatii_utilizare] INT           NOT NULL,
    [Nume]                   NVARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id_procedura] ASC), 
    CONSTRAINT [FK_Proceduri_Indicatii_de_utilizare] FOREIGN KEY ([Id_indicatii_utilizare]) REFERENCES [Indicatii_de_utilizare]([Id_indicatii_utilizare])
);

