﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AplicațieBowen
{
    public partial class Form9 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Dulau\Desktop\AplicațieBowen\AplicațieBowen\BazadedateBowen.mdf;Integrated Security=True");
        public Form9()
        {
            InitializeComponent();
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            inserare_sedinta();
            stergere_sedinta();
            actualizare_sedinta();
        }
        //Legatura cu fereastra 8
        private void Inapoi_Click(object sender, EventArgs e)
        {
            this.Close();
            Form8 frm = new Form8();
            frm.Show();
        }
        //Adaugare sedinta
        private void Adaugare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Sedinte values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
            inserare_sedinta();
            MessageBox.Show("Inregistrare facuta cu succes!");
        }
        //Adaugare 
        public void inserare_sedinta()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Sedinte";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Stergere sedinta
        private void Stergere_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from Sedinte where Id_pacient='" + textBox2.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();
            stergere_sedinta();
            MessageBox.Show("Stergere facuta cu succes!");
        }
        //Stergere
        public void stergere_sedinta()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Sedinte";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Actualizare sedinta
        private void Actualizare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update Sedinte set Nume_protocol='" + textBox3.Text + "' where Id_protocol='" + textBox1.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();
            actualizare_sedinta();
            MessageBox.Show("Actualizare facuta cu succes!");
        }
        //Actualizare
        public void actualizare_sedinta()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Sedinte";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Cautare sedinta
        private void Cautare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Sedinte where Id_pacient='" + textBox2.Text + "' or Id_protocol like '" + textBox1.Text + "' or Nume_protocol like '" + textBox3.Text + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
            MessageBox.Show("Cautare facuta cu succes!");
        }
        //Inapoi la meniul principal
        private void Meniu_Click(object sender, EventArgs e)
        {
            this.Close();
            Logare frm = new Logare();
            frm.Show();
        }
    }
}
