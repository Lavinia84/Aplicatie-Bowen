﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AplicațieBowen
{
    public partial class Form3 : Form
    {
        string[] raspunsuri = new string[25];
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Dulau\Desktop\AplicațieBowen\AplicațieBowen\BazadedateBowen.mdf;Integrated Security=True");
        public Form3()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
           
        }
       
        //Legatura cu fereastra 4
        private void Inainte_Click(object sender, EventArgs e)
        {
            raspunsuri[0] = textBox1.Text;
            raspunsuri[1] = textBox2.Text;
            raspunsuri[2] = textBox3.Text;
            raspunsuri[3] = textBox4.Text;
            raspunsuri[4] = textBox5.Text;
            raspunsuri[5] = textBox6.Text;
            raspunsuri[6] = textBox7.Text;
            raspunsuri[7] = textBox8.Text;
            raspunsuri[8] = textBox9.Text;
            raspunsuri[9] = textBox10.Text;
            raspunsuri[10] = textBox11.Text;
            raspunsuri[11] = textBox12.Text;
            raspunsuri[12] = textBox13.Text;
            this.Close();
            Form4 frm = new Form4(raspunsuri);
            frm.Show();
        }
    }
}
