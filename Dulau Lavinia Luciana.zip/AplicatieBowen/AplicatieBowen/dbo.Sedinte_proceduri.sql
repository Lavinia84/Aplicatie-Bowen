﻿CREATE TABLE [dbo].[Sedinte_proceduri]
(
	[Id_sedinta_procedura] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Id_procedura] INT NOT NULL, 
    [Id_sedinta] INT NOT NULL, 
    [Id_protocol] INT NOT NULL, 
    CONSTRAINT [FK_Sedinte_proceduri_Proceduri] FOREIGN KEY ([Id_procedura]) REFERENCES [Proceduri]([Id_procedura]), 
    CONSTRAINT [FK_Sedinte_proceduri_Sedinte] FOREIGN KEY ([Id_sedinta]) REFERENCES [Sedinte]([Id_sedinta]), 
)
