﻿CREATE TABLE [dbo].[Meridiane_proceduri]
(
	[Id_meridian_procedura] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Id_meridian] INT NOT NULL, 
    [Id_procedura] INT NOT NULL, 
    CONSTRAINT [FK_Meridiane_proceduri_Meridiane] FOREIGN KEY ([Id_meridian]) REFERENCES [Meridiane]([Id_meridian]), 
    CONSTRAINT [FK_Meridiane_proceduri_Proceduri] FOREIGN KEY ([Id_procedura]) REFERENCES [Proceduri]([Id_procedura])
)
