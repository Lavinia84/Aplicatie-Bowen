﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicațieBowen
{
    public partial class Logare : Form
    {
        string[] user = new string[2];
        public Logare()
        {
            InitializeComponent();
            
        }

        private void Logare_Load(object sender, EventArgs e)
        {

        }

        private void Utilizator_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Parolă_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        //Autentificarea
        private void Autentificare_Click(object sender, EventArgs e)
        {
          StreamWriter str = new StreamWriter("TextFile1.txt", true);
                str.WriteLine("Felix Farcaș FFAB123");
                str.Close();
          StreamReader streamReader = new StreamReader("TextFile1.txt");
            {
                string line;
                while ((line = streamReader.ReadLine()) != null)
                {
                      user = line.Split(' ');
                }
               
                    if (textBox1.Text == user[0] + " " + user[1] && textBox2.Text == user[2])
                    {
                        pictureBox1.Visible = true;
                        Proceduri.Visible = true;
                        Protocoale.Visible = true;
                        Meridiane.Visible = true;
                        FisaPacient.Visible = true;
                        DateTehnicePacient.Visible = true;
                        Utilizator.Visible = false;
                        textBox1.Visible = false;
                        Parola.Visible = false;
                        textBox2.Visible = false;
                        Autentificare.Visible = false;

                    }
                     else
                     {
                         MessageBox.Show("Utilizator sau parola incorecta, mai incearca!");
                         textBox1.Text = "";
                         textBox2.Text = "";
                     }

                
            }
            
        }
        //Minimizare
        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        //Inchidere
        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //Maximizare
        private void Maximizare_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                if (this.WindowState == FormWindowState.Maximized)
                {
                    this.WindowState = FormWindowState.Normal;
                }

            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        //Legatura cu date tehnice despre pacient
        private void DateTehnicePacient_Click(object sender, EventArgs e)
        {
            new Form2().Show();
            this.Hide();
        }
        //Afisarea datei actuale
        private void label4_Click(object sender, EventArgs e)
        {
            label4.Text = DateTime.Now.ToLongDateString();
           
        }
        //Afisarea orei actuale
        private void label6_Click(object sender, EventArgs e)
        {
            timer1.Start();
            label6.Text = DateTime.Now.ToLongTimeString();

        }
        
       
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            
        }
        //Afisarea in timp real a orei
        private void timer1_Tick_1(object sender, EventArgs e)
        {
            label6.Text = DateTime.Now.ToLongTimeString();
            timer1.Start();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
        //Legatura cu fisa pacientului
        private void FisaPacient_Click(object sender, EventArgs e)
        {
            new Form3().Show();
            this.Hide();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        //Legatura cu procedurile
        private void Proceduri_Click(object sender, EventArgs e)
        {
            new Form6().Show();
            this.Hide();
        }
        //Legatura cu protocoalele
        private void Protocoale_Click(object sender, EventArgs e)
        {
            new Form8().Show();
            this.Hide();
        }
        //Legatura cu meridianele
        private void Meridiane_Click(object sender, EventArgs e)
        {
            new Form10().Show();
            this.Hide();
        }
    }
}
