﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AplicațieBowen
{
    public partial class Form8 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Dulau\Desktop\AplicațieBowen\AplicațieBowen\BazadedateBowen.mdf;Integrated Security=True");
        public Form8()
        {
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            inserare_protocol();
            stergere_protocol();
            actualizare_protocol();
        }
        //Legatura cu fereastra 9
        private void Sedinte_Click(object sender, EventArgs e)
        {
            this.Close();
            Form9 frm = new Form9();
            frm.Show();
        }
        //Adaugare protocoale
        private void Adaugare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Protocoale values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + textBox8.Text + "','" + textBox9.Text + "','" + textBox10.Text + "','" + textBox11.Text + "','" + textBox12.Text + "','" + textBox13.Text + "','" + textBox14.Text + "','" + textBox15.Text + "','" + textBox16.Text + "','" + textBox17.Text + "','" + textBox18.Text + "','" + textBox19.Text + "','" + textBox20.Text + "','" + textBox21.Text + "','" + textBox22.Text + "','" + textBox23.Text + "','" + textBox24.Text + "','" + textBox25.Text + "','" + textBox26.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
            inserare_protocol();
            MessageBox.Show("Inregistrare facuta cu succes!");
        }
        //Adaugare 
        public void inserare_protocol()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Protocoale";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Stergere protocoale
        private void Stergere_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from Protocoale where Nume='" + textBox1.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();
            stergere_protocol();
            MessageBox.Show("Stergere facuta cu succes!");
        }
        //Stergere
        public void stergere_protocol()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Protocoale";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Actualizare protocoale
        private void Actualizare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update Protocoale set Proc_1='" + textBox2.Text + "',Proc_2='" + textBox3.Text + "',Proc_3='" + textBox4.Text + "',Proc_4='" + textBox5.Text + "',Proc_5='" + textBox6.Text + "',Proc_6='" + textBox7.Text + "',Proc_7='" + textBox8.Text + "',Proc_8='" + textBox9.Text + "',Proc_9='" + textBox10.Text + "',Proc_10='" + textBox11.Text + "',Proc_11='" + textBox12.Text + "',Proc_12='" + textBox13.Text + "',Proc_13='" + textBox14.Text + "',Proc_14='" + textBox15.Text + "',Proc_15='" + textBox16.Text + "',Proc_16='" + textBox17.Text + "',Proc_17='" + textBox18.Text + "',Proc_18='" + textBox19.Text + "',Proc_19='" + textBox20.Text + "',Proc_20='" + textBox21.Text + "',Proc_21='" + textBox22.Text + "',Proc_22='" + textBox23.Text + "',Proc_23='" + textBox24.Text + "',Proc_24='" + textBox25.Text + "',Proc_25='" + textBox26.Text + "' where Nume='" + textBox1.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();
            actualizare_protocol();
            MessageBox.Show("Actualizare facuta cu succes!");
        }
        //Actualizare
        public void actualizare_protocol()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Protocoale";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Cautare protocol
        private void Cautare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Protocoale where Nume like '" + textBox1.Text + "' or Proc_1 like '" + textBox2.Text + "' or Proc_2 like '" + textBox3.Text + "' or Proc_3 like '" + textBox4.Text + "' or Proc_4 like '" + textBox5.Text + "' or Proc_5 like '" + textBox6.Text + "' or Proc_6 like '" + textBox7.Text + "' or Proc_7 like '" + textBox8.Text + "' or Proc_8 like '" + textBox9.Text + "' or Proc_9 like '" + textBox10.Text + "' or Proc_10 like '" + textBox11.Text + "' or Proc_11 like '" + textBox12.Text + "' or Proc_12 like '" + textBox13.Text + "' or Proc_13 like '" + textBox14.Text + "' or Proc_14 like '" + textBox15.Text + "' or Proc_15 like '" + textBox16.Text + "' or Proc_16 like '" + textBox17.Text + "' or Proc_17 like '" + textBox18.Text + "' or Proc_18 like '" + textBox19.Text + "' or Proc_19 like '" + textBox20.Text + "' or Proc_20 like '" + textBox21.Text + "' or Proc_21 like '" + textBox22.Text + "' or Proc_22 like '" + textBox23.Text + "' or Proc_23 like '" + textBox24.Text + "' or Proc_24 like '" + textBox25.Text + "' or Proc_25 like '" + textBox26.Text + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
            MessageBox.Show("Cautare facuta cu succes!");
        }
        //Inapoi la meniu
        private void Meniu_Click(object sender, EventArgs e)
        {
            this.Close();
            Logare frm = new Logare();
            frm.Show();
        }
    }
}
