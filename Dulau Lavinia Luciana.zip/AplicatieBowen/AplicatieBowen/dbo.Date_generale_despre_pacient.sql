﻿CREATE TABLE [dbo].[Date_generale_despre_pacient] (
    [Id_pacient]                                          INT             IDENTITY (1, 1) NOT NULL,
    [Nume]                                                NVARCHAR (50)   NOT NULL,
    [Prenume]                                             NVARCHAR (50)   NOT NULL,
    [Data_nasterii]                                       NVARCHAR (50)   NOT NULL,
    [Nr_A]                                                INT             NOT NULL,
    [Nr_B]                                                INT             NOT NULL,
    [Varsta]                                              INT             NOT NULL,
    [Sex]                                                 NCHAR (10)      NOT NULL,
    [Greutatea]                                           DECIMAL (18)    NOT NULL,
    [Inaltimea]                                           NUMERIC (18, 2) NOT NULL,
    [Telefon]                                             INT             NOT NULL,
    [Email]                                               NVARCHAR (50)   NOT NULL,
    [Adresa]                                              NVARCHAR (50)   NOT NULL,
    [Ocupatia]                                            NVARCHAR (50)   NOT NULL,
    [Medicul_care_se_ocupa_de_pb_dvs_de_sanatate] NVARCHAR (50)   NOT NULL,
    [De_unde_aveti_ref_despre_Terapia_Bowen]        NVARCHAR (50)   NOT NULL,
    PRIMARY KEY CLUSTERED ([Id_pacient] ASC)
);

