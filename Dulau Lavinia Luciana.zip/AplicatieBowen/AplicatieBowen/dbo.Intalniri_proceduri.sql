﻿CREATE TABLE [dbo].[Intalniri_proceduri]
(
	[Id_intalnire_procedura] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Id_intalnire] INT NOT NULL, 
    [Id_procedura] INT NOT NULL, 
    CONSTRAINT [FK_Intalniri_proceduri_Intalniri] FOREIGN KEY ([Id_intalnire]) REFERENCES [Intalniri]([Id_intalnire]), 
    CONSTRAINT [FK_Intalniri_proceduri_Proceduri] FOREIGN KEY ([Id_procedura]) REFERENCES [Proceduri]([Id_procedura])
)
