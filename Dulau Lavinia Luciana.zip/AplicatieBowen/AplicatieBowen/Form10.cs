﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AplicațieBowen
{
    public partial class Form10 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Dulau\Desktop\AplicațieBowen\AplicațieBowen\BazadedateBowen.mdf;Integrated Security=True");
        public Form10()
        {
            InitializeComponent();
        }

        private void Form10_Load(object sender, EventArgs e)
        {
            inserare_meridian();
            stergere_meridian();
            actualizare_meridian();
        }
        //Adaugare meridian
        private void Adaugare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Meridiane values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + textBox8.Text + "','" + textBox9.Text + "','" + textBox10.Text + "','" + textBox11.Text + "','" + textBox12.Text + "','" + textBox13.Text + "','" + textBox14.Text + "','" + textBox15.Text + "','" + textBox16.Text + "','" + textBox17.Text + "','" + textBox18.Text + "','" + textBox19.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
            inserare_meridian();
            MessageBox.Show("Inregistrare facuta cu succes!");
        }
        //Adaugare 
        public void inserare_meridian()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Meridiane";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Stergere meridian
        private void Stergere_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from Meridiane where Nume='" + textBox3.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();
            stergere_meridian();
            MessageBox.Show("Stergere facuta cu succes!");
        }
        //Stergere
        public void stergere_meridian()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Meridiane";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Actualizare meridian
        private void Actualizare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update Meridiane set Pb_1='" + textBox4.Text + "',Pb_2='" + textBox5.Text + "',Pb_3='" + textBox6.Text + "',Pb_4='" + textBox7.Text + "',Pb_5='" + textBox8.Text + "',Pb_6='" + textBox9.Text + "',Pb_7='" + textBox10.Text + "',Pb_8='" + textBox11.Text + "',Pb_9='" + textBox12.Text + "',Pb_10='" + textBox13.Text + "',Proc_1='" + textBox14.Text + "',Proc_2='" + textBox15.Text + "',Proc_3='" + textBox16.Text + "',Proc_4='" + textBox17.Text + "',Proc_5='" + textBox18.Text + "',Proc_6='" + textBox19.Text + "'where Nume='" + textBox3.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();
            actualizare_meridian();
            MessageBox.Show("Actualizare facuta cu succes!");
        }
        //Actualizare
        public void actualizare_meridian()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Meridiane";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }
        //Cautare meridian
        private void Cautare_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Meridiane where Id_pacient='" + textBox2.Text + "' or Id_procedura='" + textBox2.Text + "' or Nume like '" + textBox3.Text + "' or Pb_1 like '" + textBox4.Text + "' or Pb_2 like '" + textBox5.Text + "' or Pb_3 like '" + textBox6.Text + "' or Pb_4 like '" + textBox7.Text + "' or Pb_5 like '" + textBox8.Text + "' or Pb_6 like '" + textBox9.Text + "' or Pb_7 like '" + textBox10.Text + "' or Pb_8 like '" + textBox11.Text + "' or Pb_9 like '" + textBox12.Text + "' or Pb_10 like '" + textBox13.Text + "' or Proc_1 like '" + textBox14.Text + "' or Proc_2 like '" + textBox15.Text + "' or Proc_3 like '" + textBox16.Text + "' or Proc_4 like '" + textBox17.Text + "' or Proc_5 like '" + textBox18.Text + "' or Proc_6 like '" + textBox19.Text + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
            MessageBox.Show("Cautare facuta cu succes!");
        }
        //Inapoi la meniul principal
        private void Meniu_Click(object sender, EventArgs e)
        {
            this.Close();
            Logare frm = new Logare();
            frm.Show();
        }
    }
}
