﻿namespace AplicațieBowen
{
    partial class Logare
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Logare));
            this.Utilizator = new System.Windows.Forms.Label();
            this.Parola = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Autentificare = new System.Windows.Forms.Button();
            this.Minimizare = new System.Windows.Forms.Button();
            this.Inchidere = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.DateTehnicePacient = new System.Windows.Forms.Button();
            this.FisaPacient = new System.Windows.Forms.Button();
            this.Meridiane = new System.Windows.Forms.Button();
            this.Protocoale = new System.Windows.Forms.Button();
            this.Proceduri = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.Ora = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.Maximizare = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Utilizator
            // 
            this.Utilizator.AutoSize = true;
            this.Utilizator.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Utilizator.ForeColor = System.Drawing.Color.Green;
            this.Utilizator.Location = new System.Drawing.Point(119, 286);
            this.Utilizator.MaximumSize = new System.Drawing.Size(100, 100);
            this.Utilizator.Name = "Utilizator";
            this.Utilizator.Size = new System.Drawing.Size(99, 24);
            this.Utilizator.TabIndex = 0;
            this.Utilizator.Text = "Utilizator:";
            this.Utilizator.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Utilizator.Click += new System.EventHandler(this.Utilizator_Click);
            // 
            // Parola
            // 
            this.Parola.AutoSize = true;
            this.Parola.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Parola.ForeColor = System.Drawing.Color.Green;
            this.Parola.Location = new System.Drawing.Point(142, 341);
            this.Parola.Name = "Parola";
            this.Parola.Size = new System.Drawing.Size(76, 24);
            this.Parola.TabIndex = 3;
            this.Parola.Text = "Parola:";
            this.Parola.Click += new System.EventHandler(this.Parolă_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.textBox1.Location = new System.Drawing.Point(251, 282);
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.textBox1.Size = new System.Drawing.Size(127, 32);
            this.textBox1.TabIndex = 3;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Autentificare
            // 
            this.Autentificare.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.Autentificare.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Autentificare.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Autentificare.Location = new System.Drawing.Point(179, 412);
            this.Autentificare.Name = "Autentificare";
            this.Autentificare.Size = new System.Drawing.Size(137, 39);
            this.Autentificare.TabIndex = 4;
            this.Autentificare.Text = "Autentificare";
            this.Autentificare.UseVisualStyleBackColor = false;
            this.Autentificare.Click += new System.EventHandler(this.Autentificare_Click);
            // 
            // Minimizare
            // 
            this.Minimizare.BackColor = System.Drawing.Color.White;
            this.Minimizare.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Minimizare.Location = new System.Drawing.Point(758, 0);
            this.Minimizare.Name = "Minimizare";
            this.Minimizare.Size = new System.Drawing.Size(40, 40);
            this.Minimizare.TabIndex = 5;
            this.Minimizare.Text = "_";
            this.Minimizare.UseVisualStyleBackColor = false;
            this.Minimizare.Click += new System.EventHandler(this.button1_Click);
            // 
            // Inchidere
            // 
            this.Inchidere.BackColor = System.Drawing.Color.Red;
            this.Inchidere.Cursor = System.Windows.Forms.Cursors.Default;
            this.Inchidere.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Inchidere.Location = new System.Drawing.Point(836, 0);
            this.Inchidere.Name = "Inchidere";
            this.Inchidere.Size = new System.Drawing.Size(44, 40);
            this.Inchidere.TabIndex = 6;
            this.Inchidere.Text = "x";
            this.Inchidere.UseVisualStyleBackColor = false;
            this.Inchidere.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.DateTehnicePacient);
            this.panel1.Controls.Add(this.FisaPacient);
            this.panel1.Controls.Add(this.Meridiane);
            this.panel1.Controls.Add(this.Protocoale);
            this.panel1.Controls.Add(this.Proceduri);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(486, 468);
            this.panel1.TabIndex = 7;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // DateTehnicePacient
            // 
            this.DateTehnicePacient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.DateTehnicePacient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DateTehnicePacient.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateTehnicePacient.Location = new System.Drawing.Point(109, 123);
            this.DateTehnicePacient.Name = "DateTehnicePacient";
            this.DateTehnicePacient.Size = new System.Drawing.Size(272, 57);
            this.DateTehnicePacient.TabIndex = 5;
            this.DateTehnicePacient.Text = "Date tehnice pacient";
            this.DateTehnicePacient.UseVisualStyleBackColor = false;
            this.DateTehnicePacient.Visible = false;
            this.DateTehnicePacient.Click += new System.EventHandler(this.DateTehnicePacient_Click);
            // 
            // FisaPacient
            // 
            this.FisaPacient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.FisaPacient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FisaPacient.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FisaPacient.Location = new System.Drawing.Point(109, 196);
            this.FisaPacient.Name = "FisaPacient";
            this.FisaPacient.Size = new System.Drawing.Size(272, 55);
            this.FisaPacient.TabIndex = 4;
            this.FisaPacient.Text = "Fișă pacient";
            this.FisaPacient.UseVisualStyleBackColor = false;
            this.FisaPacient.Visible = false;
            this.FisaPacient.Click += new System.EventHandler(this.FisaPacient_Click);
            // 
            // Meridiane
            // 
            this.Meridiane.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.Meridiane.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Meridiane.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Meridiane.Location = new System.Drawing.Point(109, 403);
            this.Meridiane.Name = "Meridiane";
            this.Meridiane.Size = new System.Drawing.Size(272, 48);
            this.Meridiane.TabIndex = 3;
            this.Meridiane.Text = "Meridiane";
            this.Meridiane.UseVisualStyleBackColor = false;
            this.Meridiane.Visible = false;
            this.Meridiane.Click += new System.EventHandler(this.Meridiane_Click);
            // 
            // Protocoale
            // 
            this.Protocoale.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.Protocoale.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Protocoale.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Protocoale.Location = new System.Drawing.Point(109, 338);
            this.Protocoale.Name = "Protocoale";
            this.Protocoale.Size = new System.Drawing.Size(272, 49);
            this.Protocoale.TabIndex = 2;
            this.Protocoale.Text = "Protocoale";
            this.Protocoale.UseVisualStyleBackColor = false;
            this.Protocoale.Visible = false;
            this.Protocoale.Click += new System.EventHandler(this.Protocoale_Click);
            // 
            // Proceduri
            // 
            this.Proceduri.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.Proceduri.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Proceduri.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Proceduri.Location = new System.Drawing.Point(109, 268);
            this.Proceduri.Name = "Proceduri";
            this.Proceduri.Size = new System.Drawing.Size(272, 56);
            this.Proceduri.TabIndex = 1;
            this.Proceduri.Text = "Proceduri";
            this.Proceduri.UseVisualStyleBackColor = false;
            this.Proceduri.Visible = false;
            this.Proceduri.Click += new System.EventHandler(this.Proceduri_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(486, 112);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.Ora);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Controls.Add(this.Autentificare);
            this.panel3.Controls.Add(this.textBox2);
            this.panel3.Controls.Add(this.Utilizator);
            this.panel3.Controls.Add(this.Parola);
            this.panel3.Controls.Add(this.textBox1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(486, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(880, 468);
            this.panel3.TabIndex = 9;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label6.Location = new System.Drawing.Point(633, 346);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 24);
            this.label6.TabIndex = 13;
            this.label6.Text = "ora";
            // 
            // Ora
            // 
            this.Ora.AutoSize = true;
            this.Ora.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ora.ForeColor = System.Drawing.Color.Green;
            this.Ora.Location = new System.Drawing.Point(545, 346);
            this.Ora.Name = "Ora";
            this.Ora.Size = new System.Drawing.Size(51, 24);
            this.Ora.TabIndex = 12;
            this.Ora.Text = "Ora:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(633, 288);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 24);
            this.label4.TabIndex = 11;
            this.label4.Text = "data";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Green;
            this.label3.Location = new System.Drawing.Point(536, 285);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 24);
            this.label3.TabIndex = 10;
            this.label3.Text = "Data:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Green;
            this.label1.Location = new System.Drawing.Point(284, 147);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(389, 72);
            this.label1.TabIndex = 9;
            this.label1.Text = "Bine ai venit!";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.Maximizare);
            this.panel2.Controls.Add(this.Minimizare);
            this.panel2.Controls.Add(this.Inchidere);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(880, 112);
            this.panel2.TabIndex = 7;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Green;
            this.label2.Location = new System.Drawing.Point(15, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(750, 43);
            this.label2.TabIndex = 10;
            this.label2.Text = "Terapia Bowen = echilibru la nivel fizic și psihic";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Maximizare
            // 
            this.Maximizare.BackColor = System.Drawing.Color.White;
            this.Maximizare.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Maximizare.BackgroundImage")));
            this.Maximizare.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Maximizare.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Maximizare.Location = new System.Drawing.Point(795, 0);
            this.Maximizare.Name = "Maximizare";
            this.Maximizare.Size = new System.Drawing.Size(41, 40);
            this.Maximizare.TabIndex = 8;
            this.Maximizare.UseVisualStyleBackColor = false;
            this.Maximizare.Click += new System.EventHandler(this.Maximizare_Click);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.textBox2.Location = new System.Drawing.Point(251, 338);
            this.textBox2.Name = "textBox2";
            this.textBox2.PasswordChar = '*';
            this.textBox2.Size = new System.Drawing.Size(127, 32);
            this.textBox2.TabIndex = 3;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // Logare
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1366, 468);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Logare";
            this.Text = "Logare";
            this.Load += new System.EventHandler(this.Logare_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label Utilizator;
        private System.Windows.Forms.Label Parola;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button Autentificare;
        private System.Windows.Forms.Button Minimizare;
        private System.Windows.Forms.Button Inchidere;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button DateTehnicePacient;
        private System.Windows.Forms.Button FisaPacient;
        private System.Windows.Forms.Button Meridiane;
        private System.Windows.Forms.Button Protocoale;
        private System.Windows.Forms.Button Proceduri;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button Maximizare;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label Ora;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Timer timer1;
    }
}

