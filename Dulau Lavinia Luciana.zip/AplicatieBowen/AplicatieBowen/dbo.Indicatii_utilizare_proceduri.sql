﻿CREATE TABLE [dbo].[Indicatii_utilizare_proceduri] (
    [Id_indicatii_utilizare_proceduri] INT NOT NULL IDENTITY,
    [Id_procedura]                     INT NOT NULL,
    [Id_indicatii_utilizare]           INT NOT NULL,
    PRIMARY KEY CLUSTERED ([Id_indicatii_utilizare_proceduri] ASC), 
    CONSTRAINT [FK_Indicatii_utilizare_proceduri_Proceduri] FOREIGN KEY ([Id_procedura]) REFERENCES [Proceduri]([Id_procedura]), 
    CONSTRAINT [FK_Indicatii_utilizare_proceduri_Indicatii_de_utilizare] FOREIGN KEY ([Id_indicatii_utilizare]) REFERENCES [Indicatii_de_utilizare]([Id_indicatii_utilizare])
);

